# Acerte o Tempo — projeto Android

Projeto Android nativo com WebView, pronto para abrir no Android Studio e gerar APK.

## Gerar o APK
1. Instale o Android Studio.
2. Abra a pasta `AcerteOTempo-Android`.
3. Espere o Gradle sincronizar.
4. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O jogo funciona offline. O jogador escolhe 5, 10, 15, 20, 30 ou 60 segundos e tenta parar o cronômetro sem ver o tempo.
